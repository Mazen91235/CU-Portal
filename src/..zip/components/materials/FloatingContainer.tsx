import React, { useEffect, useState } from "react";
import type { MaterialResponseDto } from "../../types/dtos/MaterialDtos";
import { handlePopupErrors } from "../../utils/ErrorHandling";
import { isMobile } from "../../utils/DeviceHandler";
import styles from "./FloatingContainer.module.css";

interface FloatingContainerProps {
    operation: "copy" | "move";
    materials: MaterialResponseDto[];
    selectedMaterials: number[];
    currentPath: MaterialResponseDto[];
    folders: MaterialResponseDto[];
    initialTargetId: number | null | undefined;
    onClose: () => void;
    onConfirm: (targetId: number | null) => void;
    onNavigate: (folderId: number | null) => void;
    onCreateFolder?: (name: string, parentId: number | null) => Promise<void>;
    allowCreateFolder?: boolean;
    rootLabel?: string;
    onHomeClick?: () => void;
}

export function FloatingContainer({
    operation,
    materials,
    selectedMaterials,
    currentPath,
    folders,
    initialTargetId,
    onClose,
    onConfirm,
    onNavigate,
    onCreateFolder,
    allowCreateFolder = true,
    rootLabel = "Subject Root",
    onHomeClick,
}: FloatingContainerProps) {
    const [selectedTarget, setSelectedTarget] = useState<number | null>(null);
    const [isCreatingFolder, setIsCreatingFolder] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [newFolderName, setNewFolderName] = useState("");
    const holdTimeoutRef = React.useRef<number | null>(null);
    const touchStartPositionRef = React.useRef({ x: 0, y: 0 });
    const didHoldRef = React.useRef(false);
    const touchMovedRef = React.useRef(false);
    const suppressNextClickRef = React.useRef(false);

    const selectedMaterialsData = materials.filter(
        (m) => m.id && selectedMaterials.includes(m.id),
    );
    const currentFolderId =
        currentPath.length > 0 ? currentPath[currentPath.length - 1].id : null;

    useEffect(() => {
        setSelectedTarget(initialTargetId || null);
    }, [initialTargetId]);

    const handleConfirm = () => {
        onConfirm(selectedTarget);
    };

    const clearHoldTimeout = () => {
        if (holdTimeoutRef.current !== null) {
            window.clearTimeout(holdTimeoutRef.current);
            holdTimeoutRef.current = null;
        }
    };

    useEffect(() => () => {
        if (holdTimeoutRef.current !== null) {
            window.clearTimeout(holdTimeoutRef.current);
        }
    }, []);

    const handleFolderClick = (folderId: number) => {
        if (isMobile()) {
            if (suppressNextClickRef.current) {
                suppressNextClickRef.current = false;
                return;
            }
            onNavigate(folderId);
            setSelectedTarget(folderId);
            return;
        }

        if (selectedTarget === folderId) {
            setSelectedTarget(null);
        } else {
            setSelectedTarget(folderId);
        }
    };

    const handleFolderHold = (folderId: number) => {
        if (isMobile()) {
            setSelectedTarget(folderId);
        }
    };

    const handleFolderDoubleClick = (folderId: number) => {
        if (!isMobile()) {
            onNavigate(folderId);
            setSelectedTarget(folderId);
        }
    };

    const handleFolderTouchStart = (
        e: React.TouchEvent<HTMLDivElement>,
        folderId: number,
    ) => {
        if (!isMobile() || e.touches.length !== 1) return;

        const touch = e.touches[0];
        touchStartPositionRef.current = { x: touch.clientX, y: touch.clientY };
        didHoldRef.current = false;
        touchMovedRef.current = false;
        suppressNextClickRef.current = false;
        clearHoldTimeout();
        holdTimeoutRef.current = window.setTimeout(() => {
            didHoldRef.current = true;
            suppressNextClickRef.current = true;
            handleFolderHold(folderId);
        }, 400);
    };

    const handleFolderTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
        if (!isMobile() || e.touches.length !== 1 || didHoldRef.current) return;

        const touch = e.touches[0];
        const moveX = Math.abs(touch.clientX - touchStartPositionRef.current.x);
        const moveY = Math.abs(touch.clientY - touchStartPositionRef.current.y);
        if (moveX > 10 || moveY > 10) {
            touchMovedRef.current = true;
            suppressNextClickRef.current = true;
            clearHoldTimeout();
        }
    };

    const handleFolderTouchEnd = () => {
        if (!isMobile()) return;
        clearHoldTimeout();
        if (!didHoldRef.current && !touchMovedRef.current) {
            suppressNextClickRef.current = false;
        }
        didHoldRef.current = false;
        touchMovedRef.current = false;
    };

    const handleRootClick = () => {
        onNavigate(null);
        setSelectedTarget(null);
    };

    const handleCreateFolder = async () => {
        if (!newFolderName.trim() || !onCreateFolder) {
            return;
        }
        try {
            setIsLoading(true);
            await onCreateFolder(newFolderName.trim(), currentFolderId ?? null);
            setNewFolderName("");
            setIsCreatingFolder(false);
        } catch (error) {
            handlePopupErrors(error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleCancelCreateFolder = () => {
        setNewFolderName("");
        setIsCreatingFolder(false);
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === "Enter") {
            handleCreateFolder();
        } else if (e.key === "Escape") {
            handleCancelCreateFolder();
        }
    };

    return (
        <div className={styles.overlay} onClick={onClose}>
            <div
                className={styles.container}
                onClick={(e) => e.stopPropagation()}
            >
                <div className={styles.header}>
                    <h3 className={styles.dialogTitle}>
                        {operation === "copy" ? "Copy" : "Move"}{" "}
                        {selectedMaterialsData.length === 1
                            ? `"${selectedMaterialsData[0].name}"`
                            : `${selectedMaterials.length} items`}{" "}
                        to...
                    </h3>
                    <button className={styles.closeButton} onClick={onClose}>
                        ×
                    </button>
                </div>

                <div className={styles.navigationPath}>
                    <div
                        className={styles.pathSegment}
                        onClick={onHomeClick}
                        style={{ cursor: onHomeClick ? "pointer" : "default" }}
                    >
                        <svg
                            width="18"
                            height="18"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                        >
                            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
                        </svg>
                        Materials
                    </div>
                    <div className={styles.pathSeparator}>{">"}</div>
                    <div
                        className={`${styles.pathSegment} ${!currentPath.length ? styles.active : ""}`}
                        onClick={handleRootClick}
                        style={{
                            cursor:
                                currentFolderId === null
                                    ? "default"
                                    : "pointer",
                        }}
                    >
                        {rootLabel}
                    </div>
                    {currentPath.map((folder, index) => (
                        <React.Fragment key={folder.id}>
                            <div className={styles.pathSeparator}>{">"}</div>
                            <div
                                className={`${styles.pathSegment} ${index === currentPath.length - 1 ? styles.active : ""}`}
                                onClick={() =>
                                    index !== currentPath.length - 1 &&
                                    folder.id &&
                                    onNavigate(folder.id)
                                }
                                style={{
                                    cursor:
                                        index === currentPath.length - 1
                                            ? "default"
                                            : "pointer",
                                }}
                            >
                                {folder.name}
                            </div>
                        </React.Fragment>
                    ))}
                    {allowCreateFolder && (
                        <button
                            className={styles.newFolderBtn}
                            onClick={() => setIsCreatingFolder(true)}
                        >
                            <svg
                                width="14"
                                height="14"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.5"
                            >
                                <line x1="12" y1="5" x2="12" y2="19" />
                                <line x1="5" y1="12" x2="19" y2="12" />
                            </svg>
                            New Folder
                        </button>
                    )}
                </div>

                {allowCreateFolder && isCreatingFolder && (
                    <div className={styles.addFolderContainer}>
                        <input
                            type="text"
                            className={styles.newFolderInput}
                            placeholder="Folder name"
                            value={newFolderName}
                            onChange={(e) => setNewFolderName(e.target.value)}
                            onKeyDown={handleKeyPress}
                            disabled={isLoading}
                            autoFocus
                        />
                        <div className={styles.newFolderActions}>
                            <button
                                className={styles.createButton}
                                onClick={handleCreateFolder}
                                disabled={!newFolderName.trim() || isLoading}
                            >
                                Create
                            </button>
                            <button
                                className={styles.cancelCreateButton}
                                onClick={handleCancelCreateFolder}
                                disabled={isLoading}
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                )}

                <div className={styles.folderList}>
                    {folders.length === 0 ? (
                        <div className={styles.emptyState}>
                            <svg
                                width="64"
                                height="64"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="1.5"
                            >
                                <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                            </svg>
                            <h3>No Folders Found.</h3>
                            <p>
                                {allowCreateFolder
                                    ? "Create a new folder or just leave materials here."
                                    : "Navigate into an existing folder to copy here."}
                            </p>
                        </div>
                    ) : (
                        folders.map((folder) => (
                            <div
                                key={folder.id}
                                className={`${styles.folderItem} ${selectedTarget === folder.id ? styles.selectedFolder : ""}`}
                                onClick={() =>
                                    folder.id && handleFolderClick(folder.id)
                                }
                                onDoubleClick={() =>
                                    folder.id &&
                                    handleFolderDoubleClick(folder.id)
                                }
                                onTouchStart={(e) =>
                                    folder.id &&
                                    handleFolderTouchStart(e, folder.id)
                                }
                                onTouchMove={handleFolderTouchMove}
                                onTouchEnd={handleFolderTouchEnd}
                                onContextMenu={(e) => {
                                    if (isMobile()) e.preventDefault();
                                }}
                            >
                                <div className={styles.folderIcon}>
                                    <svg
                                        width="20"
                                        height="20"
                                        viewBox="0 0 24 24"
                                        fill="none"
                                        stroke="currentColor"
                                        strokeWidth="2"
                                    >
                                        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                                    </svg>
                                </div>
                                <span className={styles.folderName}>
                                    {folder.name && folder.name.length > 20
                                        ? folder.name.substring(0, 15) +
                                          "..." +
                                          folder.name.substring(
                                              folder.name.length - 5,
                                          )
                                        : folder.name || "Untitled"}
                                </span>
                            </div>
                        ))
                    )}
                </div>

                <div className={styles.footer}>
                    <button className={styles.cancelButton} onClick={onClose}>
                        Cancel
                    </button>
                    <button
                        className={styles.confirmButton}
                        onClick={handleConfirm}
                    >
                        {operation === "copy" ? "Copy Here" : "Move Here"}
                    </button>
                </div>
            </div>
        </div>
    );
}
