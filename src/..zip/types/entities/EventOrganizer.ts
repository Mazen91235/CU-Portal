import type { Event } from "./Event";
import type { Attachment } from "./Attachment";

export type EventOrganizer = {
    id?: number;
    name?: string;
    details?: object | null;
    created_at?: Date | null;
    updated_at?: Date | null;
    events?: Event[] | null;
    logo_id?: number | null;
    logo?: Attachment | null;
    attachments?: Attachment[] | null;
};
