import type { DepartmentStudyType } from "../entities/Department";
import type { UserResponseDto } from "./UserDtos";
import type { FacultyResponseDto } from "./FacultyDtos";
import type { SubjectResponseDto } from "./SubjectDtos";
import type { TaskResponseDto } from "./TaskDtos";
import type { AnnouncementResponseDto } from "./AnnouncementDtos";
import type { WeekResponseDto } from "./WeekDtos";
import type { SearchDto } from "./BaseDtos";

export type DepartmentCreateDto = {
    name: string;
    code: string;
    faculty_id: number;
    study_type: DepartmentStudyType;
};

export type DepartmentResponseDto = {
    id?: number | null;
    name?: string | null;
    code?: string | null;
    details?: object | null;
    study_type?: DepartmentStudyType | null;
    created_at?: string | null;
    updated_at?: string | null;
    faculty?: FacultyResponseDto | null;
    users?: UserResponseDto[] | null;
    subjects?: SubjectResponseDto[] | null;
    tasks?: TaskResponseDto[] | null;
    announcements?: AnnouncementResponseDto[] | null;
    weeks?: WeekResponseDto[] | null;
};

export type DepartmentUpdateDto = {
    name: string;
    code: string;
    faculty_id: number;
    study_type: DepartmentStudyType;
};

export type DepartmentSearchDto = {
    id?: number | null;
    faculty_id?: number | null;
    study_type?: DepartmentStudyType | null;
    created_at_from?: string | null;
    created_at_to?: string | null;
    updated_at_from?: string | null;
    updated_at_to?: string | null;
} & SearchDto;
