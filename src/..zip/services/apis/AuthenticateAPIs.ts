import { createApi, fetchBaseQuery, retry } from "@reduxjs/toolkit/query/react";
import { SetCookie } from "../../utils/CookiesManager";
import type { GenericAPIResponse } from "../../types/responses/GenericAPIResponse";
import type {
    UserCreateDto,
    UserGetStoredAccessTokenDto,
    UserVerifyEmailDto,
    UserTokenDetailsResponseDto,
} from "../../types/dtos/UserDtos";
import { GetApiLink } from "../../utils/LinkHandler";
import { timeout, maxRetries, retryCondition } from "../../utils/APIHandling";
export const AuthenticateAPI = createApi({
    reducerPath: "authenticateAPI",
    baseQuery: retry(
        fetchBaseQuery({
            baseUrl: GetApiLink("/auth"),
            timeout,
            credentials: "include",
        }),
        {
            maxRetries,
            //@ts-expect-error RTK Query's types don't account for this parameter
            retryCondition,
        },
    ),
    endpoints: (builder) => ({
        logout: builder.query<GenericAPIResponse, void>({
            query: () => ({
                url: "/logout",
                method: "GET",
                credentials: "include",
            }),
            onQueryStarted: async (_, { queryFulfilled }) => {
                try {
                    const data = (await queryFulfilled).data;
                    if (data.success) {
                        SetCookie("google_details_token", "", -1);
                        SetCookie("oauth_state", "", -1);
                        localStorage.removeItem("user");
                        localStorage.removeItem("permissions");
                    }
                } catch {
                    return;
                }
            },
        }),
        isLoggedIn: builder.query<GenericAPIResponse, void>({
            query: () => ({
                url: "/is-logged-in",
                method: "GET",
                credentials: "include",
            }),
        }),
        getGoogleStoredToken: builder.mutation<
            GenericAPIResponse<string>,
            UserGetStoredAccessTokenDto
        >({
            query: (data) => ({
                url: "/google-stored-token",
                method: "POST",
                body: data,
                credentials: "include",
            }),
        }),
        getGoogleAccessToken: builder.query<GenericAPIResponse<string>, void>({
            query: () => ({
                url: "/google-access-token",
                method: "GET",
                credentials: "include",
            }),
        }),
        register: builder.mutation<GenericAPIResponse, UserCreateDto>({
            query: (data) => ({
                url: "/register",
                method: "POST",
                body: data,
                credentials: "include",
            }),
            onQueryStarted: async (_, { queryFulfilled }) => {
                try {
                    const response = (await queryFulfilled).data;
                    if (response.success) {
                        SetCookie("google_details_token", "", -1);
                        SetCookie("oauth_state", "", -1);
                    }
                } catch {
                    return;
                }
            },
        }),
        verifyEmail: builder.mutation<GenericAPIResponse, UserVerifyEmailDto>({
            query: (data) => ({
                url: "/verify-email",
                method: "POST",
                body: data,
                credentials: "include",
            }),
        }),
        resendToken: builder.mutation<GenericAPIResponse, void>({
            query: () => ({
                url: "/resend-token",
                method: "POST",
                credentials: "include",
            }),
        }),
        getTokenDetails: builder.query<
            GenericAPIResponse<UserTokenDetailsResponseDto>,
            void
        >({
            query: () => ({
                url: "/token-details",
                method: "GET",
                credentials: "include",
            }),
        }),
    }),
});

export const {
    useLazyIsLoggedInQuery,
    useLazyLogoutQuery,
    useGetGoogleStoredTokenMutation,
    useLazyGetGoogleAccessTokenQuery,
    useRegisterMutation,
    useVerifyEmailMutation,
    useResendTokenMutation,
    useLazyGetTokenDetailsQuery,
} = AuthenticateAPI;
