import { useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router";
import { useLazyGetAnnouncementQuery } from "../../../services/apis/user/AnnouncementAPIs";
import type { AnnouncementResponseDto } from "../../../types/dtos/AnnouncementDtos";
import { PageSeo } from "../../../components/PageSeo";
import { Layout } from "../../../components/layout/Layout";
import { SubBanner } from "../../../components/banner/SubBanner";
import { StatCard } from "../../../components/card/StatCard";
import { AttachmentsAndLinksSection } from "../../../components/preview/AttachmentsAndLinksSection";
import { QuickInfoSection } from "../../../components/section/QuickInfoSection";
import { LongSection } from "../../../components/section/LongSection";
import useAuthQuery from "../../../hooks/useAuthQuery";
import { getErrorMessage } from "../../../utils/ErrorHandling";
import { formatDateTime } from "../../../utils/Formatter";

import styles from "./AnnouncementPage.module.css";

export const AnnouncementPage = () => {
    const { announcementId } = useParams<{ announcementId: string }>();
    const navigate = useNavigate();
    const [announcement, setAnnouncement] =
        useState<AnnouncementResponseDto | null>(null);

    const [getAnnouncement] = useLazyGetAnnouncementQuery();

    const fetchAnnouncement = useCallback(async () => {
        if (!announcementId) return;

        try {
            const result = await getAnnouncement({
                announcement_id: parseInt(announcementId),
            }).unwrap();
            const announcement = result.data;
            if (!announcement) {
                navigate("/user/announcements", {
                    state: { error: "Failed to fetch announcement" },
                });
                return;
            }
            setAnnouncement(announcement);
        } catch (error) {
            navigate("/user/announcements", {
                state: { error: getErrorMessage(error) || "Failed to fetch announcement" },
            });
        }
    }, [getAnnouncement, navigate, announcementId]);

    const authQueryParams = useCallback(
        () => fetchAnnouncement(),
        [fetchAnnouncement],
    );

    useAuthQuery(authQueryParams);

    if (!announcement) {
        return null;
    }

    return (
        <Layout>
            <PageSeo
                title={`${announcement.title} - Announcement Details - CU Portal`}
                description={`View announcement information for ${announcement.title}`}
            />

            <SubBanner
                title={announcement.title || "Announcement Details"}
                icon="announcements"
                linkText="Back to Announcements"
                linkTo="/user/announcements"
            />

            <div className={styles.container}>
                <div className={styles.statsRow}>
                    <StatCard
                        type="Subject"
                        value={announcement.subject?.name || "N/A"}
                        icon="book"
                    />
                    <StatCard
                        type="Date"
                        value={formatDateTime(announcement.date) || "N/A"}
                        icon="calendar"
                    />
                    <StatCard
                        type="Created At"
                        value={formatDateTime(announcement.created_at) || "N/A"}
                        icon="calendar"
                    />
                </div>

                <div className={styles.contentGrid}>
                    <div className={styles.mainContent}>
                        <LongSection title="Content" icon="align-left">
                            <div className={styles.detailsSection}>
                                {announcement.content || (
                                    <span>No content available</span>
                                )}

                                {announcement.attachments &&
                                    announcement.attachments.length > 0 && (
                                        <AttachmentsAndLinksSection
                                            attachments={
                                                announcement.attachments
                                            }
                                        />
                                    )}
                            </div>
                        </LongSection>
                    </div>

                    <div className={styles.sidebar}>
                        <QuickInfoSection
                            items={[{ label: "Type:", value: "Announcement" }]}
                        />
                    </div>
                </div>
            </div>
        </Layout>
    );
};
