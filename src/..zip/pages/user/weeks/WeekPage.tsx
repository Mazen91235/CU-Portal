import { useCallback, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router";
import styles from "./WeekPage.module.css";
import { Layout } from "../../../components/layout/Layout";
import { Banner } from "../../../components/banner/Banner";
import { SubBanner } from "../../../components/banner/SubBanner";
import { PageSeo } from "../../../components/PageSeo";
import { Preview } from "../../../components/preview/Preview";
import { MaterialActionsDropdown } from "../../../components/materials/MaterialActionsDropdown";
import { downloadFile } from "../../../utils/FileDownloader";
import {
    getErrorMessage,
    handlePopupErrors,
} from "../../../utils/ErrorHandling";
import { getFileIcon } from "../../../utils/MaterialHelpers";
import {
    formatDate,
    formatDateTime,
    formatTimeAgo,
    formatString,
} from "../../../utils/Formatter";
import { FaChevronUp } from "react-icons/fa";
import { MonthPicker } from "../../../components/timeline/MonthPicker";
import { EmptySection } from "../../../components/calendar/EmptySection";
import {
    useLazyGetWeekQuery,
    useLazyGetWeeksQuery,
} from "../../../services/apis/user/WeekAPIs";
import useAuthQuery from "../../../hooks/useAuthQuery";
import { useAppSelector } from "../../../services/redux/Hooks";
import type { WeekResponseDto } from "../../../types/dtos/WeekDtos";
import { getWeekEndDate } from "../../../utils/WeekHelpers";
import type { WeekItemResponseDto } from "../../../types/dtos/WeekItemDtos";

/* ---------- Types ---------- */

function WeeklyMaterialCard({ item }: { item: WeekItemResponseDto }) {
    const [previewFile, setPreviewFile] = useState<{
        id: string;
        name: string;
    } | null>(null);

    const material = item.material;
    if (!material) return null;

    const fileData = material.attachment?.details?.file_data;
    const fileType =
        fileData?.file_type || fileData?.type || material.material_type;
    const isFile = material.material_type === "file";
    const isLink =
        material.material_type === "drive" ||
        material.material_type === "youtube" ||
        material.material_type === "external";

    const handlePreview = () => {
        if (fileData?.id) {
            setPreviewFile({
                id: fileData.id,
                name: material.name || "Preview",
            });
        }
    };

    const handleDownload = async () => {
        if (!fileData?.id) return;
        try {
            downloadFile(fileData.id);
        } catch (error) {
            handlePopupErrors(error);
        }
    };

    const handleOpenLink = () => {
        const url = material.attachment?.url;
        if (url) window.open(url, "_blank", "noopener,noreferrer");
    };

    return (
        <>
            <article className={styles.fileCard}>
                <div className={styles.fileMain}>
                    <div className={styles.fileInfo}>
                        <img
                            src={getFileIcon(fileType || undefined)}
                            alt=""
                            className={styles.fileIcon}
                        />
                        <div className={styles.fileText}>
                            <span className={styles.fileName}>
                                {formatString(
                                    material.name || "Unnamed material",
                                    "CardTitle",
                                )}
                            </span>
                            <span className={styles.fileMeta}>
                                {formatTimeAgo(
                                    material.updated_at ||
                                        material.created_at ||
                                        "",
                                )}
                            </span>
                        </div>
                    </div>

                    {(isFile || isLink) && (
                        <>
                            <div className={styles.fileActions}>
                                {isFile && fileData?.id && (
                                    <>
                                        <button
                                            type="button"
                                            className={styles.fileActionButton}
                                            onClick={handlePreview}
                                        >
                                            <i
                                                className="fas fa-eye"
                                                aria-hidden="true"
                                            />
                                            Preview
                                        </button>
                                        <button
                                            type="button"
                                            className={styles.fileActionButton}
                                            onClick={() =>
                                                void handleDownload()
                                            }
                                        >
                                            <i
                                                className="fas fa-download"
                                                aria-hidden="true"
                                            />
                                            Download
                                        </button>
                                    </>
                                )}
                                {isLink && material.attachment?.url && (
                                    <button
                                        type="button"
                                        className={styles.fileActionButton}
                                        onClick={handleOpenLink}
                                    >
                                        <i
                                            className="fas fa-external-link"
                                            aria-hidden="true"
                                        />
                                        Open
                                    </button>
                                )}
                            </div>

                            <div className={styles.fileActionsMobile}>
                                <MaterialActionsDropdown
                                    onShare={() => {}}
                                    onMove={() => {}}
                                    onCopy={() => {}}
                                    onEdit={() => {}}
                                    onDelete={() => {}}
                                    onView={
                                        isFile ? handlePreview : handleOpenLink
                                    }
                                    onDownload={
                                        isFile && fileData?.id
                                            ? () => void handleDownload()
                                            : undefined
                                    }
                                    showShare={false}
                                    showMove={false}
                                    showCopy={false}
                                    showEdit={false}
                                    showDelete={false}
                                    showDownload={
                                        isFile && Boolean(fileData?.id)
                                    }
                                />
                            </div>
                        </>
                    )}
                </div>
                {item.note?.trim() && (
                    <div className={styles.itemNote}>
                        {formatString(item.note, "Content")}
                    </div>
                )}
            </article>
            {previewFile && (
                <Preview
                    file_id={previewFile.id}
                    fileName={previewFile.name}
                    onClose={() => setPreviewFile(null)}
                    onDownload={handleDownload}
                />
            )}
        </>
    );
}

/* ---------- Accordion section ---------- */

function AccordionSection({
    title,
    weekItems,
}: {
    title: string;
    weekItems: WeekItemResponseDto[];
}) {
    const [open, setOpen] = useState(true);
    const count = weekItems.length;

    return (
        <div className={styles.section}>
            <button
                type="button"
                className={styles.sectionHeader}
                onClick={() => setOpen((v) => !v)}
                aria-expanded={open}
            >
                <span className={styles.sectionTitle}>
                    {title}
                    <span className={styles.sectionCount}>
                        ({count} {count === 1 ? "Item" : "Items"})
                    </span>
                </span>
                <span
                    className={`${styles.chevron} ${open ? styles.chevronOpen : ""}`}
                >
                    <FaChevronUp aria-hidden="true" />
                </span>
            </button>

            {open && count > 0 && (
                <div className={styles.sectionBody}>
                    {weekItems.map((item) => (
                        <WeeklyMaterialCard
                            key={item.id ?? item.material?.id}
                            item={item}
                        />
                    ))}
                </div>
            )}
        </div>
    );
}

export default function WeekMaterials({
    weekNumber,
    weekItems,
    onWeekChange,
    isLoading,
    periodLabel,
    previousDisabled,
    nextDisabled,
}: {
    weekItems: WeekItemResponseDto[];
    weekNumber: number;
    onWeekChange: (amount: number) => void;
    isLoading: boolean;
    periodLabel?: string;
    previousDisabled: boolean;
    nextDisabled: boolean;
}) {
    const sections = useMemo(() => {
        const grouped = new Map<string, WeekItemResponseDto[]>();
        (weekItems || []).forEach((weekItem) => {
            const material = weekItem.material;
            const subjectId = material?.subject?.id ?? "other";
            const title = material?.subject?.name || "Other Materials";
            const key = `${subjectId}:${title}`;
            const items = grouped.get(key) || [];
            items.push(weekItem);
            grouped.set(key, items);
        });
        return Array.from(grouped.values()).map(
            (items) =>
                [
                    items[0]?.material?.subject?.name || "Other Materials",
                    items,
                ] as [string, WeekItemResponseDto[]],
        );
    }, [weekItems]);

    return (
        <section className={styles.panel}>
            <div className={styles.weekPicker}>
                <MonthPicker
                    mode="week"
                    weekNumber={weekNumber}
                    periodLabel={periodLabel}
                    previousDisabled={previousDisabled}
                    nextDisabled={nextDisabled}
                    onPeriodChange={(_, amount) => onWeekChange(amount)}
                />
            </div>
            {sections.length > 0 ? (
                <div className={styles.sectionsList}>
                    {sections.map(([title, items]) => (
                        <AccordionSection
                            key={title}
                            title={title}
                            weekItems={items}
                        />
                    ))}
                </div>
            ) : (
                !isLoading && (
                    <EmptySection
                        icon="calendar"
                        title="No materials or weeks found for this week."
                    />
                )
            )}
        </section>
    );
}

export function WeekPage() {
    const { weekId: routeWeekId } = useParams();
    const navigate = useNavigate();
    const [week, setWeek] = useState<WeekResponseDto | null>(null);
    const [weekItems, setWeekItems] = useState<WeekItemResponseDto[]>([]);
    const user = useAppSelector((state) => state.user.user);
    const [getWeek] = useLazyGetWeekQuery();
    const [getWeeks] = useLazyGetWeeksQuery();

    const academicWeekFilter = useMemo(() => {
        return {
            faculty_id: user?.faculty?.id || undefined,
            department_id: user?.department?.id || undefined,
            year_id: user?.year?.id || undefined,
        };
    }, [user]);

    const fetchWeek = useCallback(async () => {
        try {
            const today = new Date().toLocaleDateString("en-CA");
            let selectedWeek: WeekResponseDto | undefined;

            if (routeWeekId) {
                selectedWeek =
                    (
                        await getWeek({
                            week_id: Number(routeWeekId),
                        }).unwrap()
                    ).data ?? undefined;

                if (!selectedWeek) {
                    navigate("/user/weeks", {
                        state: { error: "Failed to fetch week" },
                    });
                    return;
                }
            } else {
                selectedWeek = (
                    await getWeeks({
                        data: {
                            ...academicWeekFilter,
                            start_date_includes: today,
                        },
                        includes: [
                            "faculty",
                            "department",
                            "year",
                            "week_items.material.subject",
                            "week_items.material.attachment",
                        ],
                        order_by: ["start_date"],
                        limit: 1,
                    }).unwrap()
                ).data?.[0];

                if (!selectedWeek) {
                    selectedWeek = (
                        await getWeeks({
                            data: {
                                ...academicWeekFilter,
                                start_date_to: today,
                            },
                            includes: [
                                "faculty",
                                "department",
                                "year",
                                "week_items.material.subject",
                                "week_items.material.attachment",
                            ],
                            order_by: ["start_date"],
                            descending: true,
                            limit: 1,
                        }).unwrap()
                    ).data?.[0];
                }

                if (!selectedWeek) {
                    selectedWeek = (
                        await getWeeks({
                            data: {
                                ...academicWeekFilter,
                                start_date_from: today,
                            },
                            includes: [
                                "faculty",
                                "department",
                                "year",
                                "week_items.material.subject",
                                "week_items.material.attachment",
                            ],
                            order_by: ["start_date"],
                            limit: 1,
                        }).unwrap()
                    ).data?.[0];
                }
            }

            setWeek(selectedWeek || null);

            if (!routeWeekId && selectedWeek?.id) {
                navigate(`/user/weeks/${selectedWeek.id}`, { replace: true });
            }

            setWeekItems(selectedWeek?.week_items || []);
        } catch (error) {
            navigate("/user/weeks", {
                state: {
                    error: getErrorMessage(error) || "Failed to fetch week",
                },
            });
        }
    }, [getWeek, getWeeks, navigate, routeWeekId, academicWeekFilter]);

    useAuthQuery(fetchWeek);

    const handleWeekChange = (amount: number) => {
        if (!week?.start_date) return;
        if (amount < 0) {
            const targetDate = new Date(formatDateTime(week.start_date, true));
            targetDate.setUTCDate(targetDate.getUTCDate() - 1);
            void getWeeks({
                data: {
                    ...academicWeekFilter,
                    start_date_to: targetDate.toISOString().slice(0, 10),
                },
                order_by: ["start_date"],
                descending: true,
                limit: 1,
            })
                .unwrap()
                .then((response) => {
                    if (response.data?.[0]?.id)
                        navigate(`/user/weeks/${response.data[0].id}`);
                });
            return;
        }
        const targetDate = new Date(formatDateTime(week.start_date, true));
        targetDate.setUTCDate(targetDate.getUTCDate() + 7);
        void getWeeks({
            data: {
                ...academicWeekFilter,
                start_date_from: targetDate.toISOString().slice(0, 10),
            },
            order_by: ["start_date"],
            limit: 1,
        })
            .unwrap()
            .then((response) => {
                if (response.data?.[0]?.id)
                    navigate(`/user/weeks/${response.data[0].id}`);
            });
    };

    return (
        <Layout>
            <PageSeo
                title="Weekly Guide - CU Portal"
                description="Weekly Guide for students to access their course materials and resources."
            />
            {routeWeekId ? (
                <SubBanner
                    title={
                        week?.week_number
                            ? `Week ${week.week_number}`
                            : "Weekly Guide"
                    }
                    description="Weekly Guide for students to access their course materials and resources."
                    linkText="Back to Weekly Guide"
                    linkTo="/user/weeks"
                />
            ) : (
                <Banner
                    title="My Weekly Guide"
                    description="Weekly Guide for students to access their course materials and resources."
                />
            )}
            <div className={styles.container}>
                <WeekMaterials
                    weekItems={weekItems}
                    weekNumber={week?.week_number || 0}
                    onWeekChange={handleWeekChange}
                    isLoading={false}
                    periodLabel={
                        week?.week_number
                            ? `Week ${week.week_number} (${formatDate(week.start_date, false)} - ${formatDate(getWeekEndDate(week.start_date), false)})`
                            : "No weeks available"
                    }
                    previousDisabled={!week?.start_date}
                    nextDisabled={!week?.start_date}
                />
            </div>
        </Layout>
    );
}
