import { useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router";
import { buildRedirectUrl } from "../../../utils/Navigation";
import {
  useLazyGetExamQuery,
  useDeleteExamMutation,
} from "../../../services/apis/admin/ExamAPIs";
import type { ExamResponseDto } from "../../../types/dtos/ExamDtos";
import { PageSeo } from "../../../components/PageSeo";
import { Layout } from "../../../components/layout/Layout";
import { SubBanner } from "../../../components/banner/SubBanner";
import { StatCard } from "../../../components/card/StatCard";
import { QuickInfoSection } from "../../../components/section/QuickInfoSection";
import { LongSection } from "../../../components/section/LongSection";
import ConfirmModal from "../../../components/modal/ConfirmModal";
import useAuthQuery from "../../../hooks/useAuthQuery";
import { getErrorMessage, handlePopupErrors } from "../../../utils/ErrorHandling";

import { formatDateTime } from "../../../utils/Formatter";

import styles from "./ExamPage.module.css";

export const ExamPage = () => {
  const { examId } = useParams<{ examId: string }>();
  const navigate = useNavigate();
  const [exam, setExam] = useState<ExamResponseDto | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  const [getExam] = useLazyGetExamQuery();
  const [deleteExam] = useDeleteExamMutation();

  const fetchExam = useCallback(async () => {
    if (!examId) return;

    try {
      const result = await getExam({
        exam_id: parseInt(examId),
      }).unwrap();
      const exam = result.data;
      if (!exam) {
        navigate("/admin/exams", {
          state: { error: "Failed to fetch exam" },
        });
        return;
      }
      setExam(exam);
    } catch (error) {
      navigate("/admin/exams", {
        state: { error: getErrorMessage(error) || "Failed to fetch exam" },
      });
    }
  }, [getExam, navigate, examId]);

  const authQueryParams = useCallback(() => fetchExam(), [fetchExam]);

  useAuthQuery(authQueryParams);

  const handleDeleteClick = () => {
    setIsDeleteModalOpen(true);
  };

  const handleDelete = async () => {
    if (!exam?.id) return;

    try {
      await deleteExam({ exam_id: exam.id }).unwrap();
      navigate("/admin/exams", {
        state: { success: "Exam deleted successfully" },
      });
    } catch (error) {
      handlePopupErrors(error);
    }
  };

  if (!exam) {
    return null;
  }

  return (
    <Layout>
      <PageSeo
        title={`${exam.name} - Exam Details - CU Portal`}
        description={`View and manage exam information for ${exam.name}`}
      />

      <SubBanner
        title={exam.name || "Exam Details"}
        icon="task"
        button="Edit Exam"
        buttonAction={() => navigate(buildRedirectUrl(`/admin/exams/edit/${exam.id}`))}
        deleteButton="Delete Exam"
        deleteAction={handleDeleteClick}
        linkText="Back to Exams"
        linkTo="/admin/exams"
      />

      <div className={styles.container}>
        <div className={styles.statsRow}>
          <StatCard
            type="Subject"
            value={exam.subject?.name || "N/A"}
            icon="book"
          />
          <StatCard
            type="Date"
            value={formatDateTime(exam.deadline) || "N/A"}
            icon="calendar"
          />
          <StatCard
            type="Duration"
            value={
              exam.details?.duration ? `${exam.details.duration} minutes` : "N/A"
            }
            icon="clock"
          />
        </div>

        <div className={styles.contentGrid}>
          <div className={styles.mainContent}>
            {exam.details?.instructions && (
              <LongSection title="Exam Instructions" icon="file-text">
                <div className={styles.instructionsContent}>
                  {exam.details.instructions && (
                    <ul>
                      {exam.details.instructions
                        .split("\n")
                        .map((instruction, index) => (
                          <div key={index} className={styles.instruction}>
                            <li>{instruction}</li>
                          </div>
                        ))}
                    </ul>
                  )}
                </div>
              </LongSection>
            )}

            <LongSection title="Description" icon="align-left">
              {exam.details?.description || (
                <span>No description available</span>
              )}
            </LongSection>
          </div>

          <div className={styles.sidebar}>
            <QuickInfoSection
              items={[
                { label: "Type:", value: "Exam" },
                {
                  label: "Location:",
                  value: exam.details?.location || "N/A",
                },
                {
                  label: "Faculty:",
                  value: exam.subject?.faculty?.name || "N/A",
                },
                {
                  label: "Department:",
                  value: exam.subject?.department?.name || "N/A",
                },
                {
                  label: "Year:",
                  value: exam.subject?.year?.year?.toString() || "N/A",
                },
                {
                  label: "Exam Type:",
                  value: exam.details?.exam_type || "N/A",
                },
                {
                  label: "Format:",
                  value: exam.details?.exam_format || "N/A",
                },
                {
                  label: "Weight:",
                  value: exam.details?.exam_weight || "N/A",
                },
              ]}
            />
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleDelete}
        confirmText="Delete"
        title="Delete Exam"
        message={`Are you sure you want to delete "${exam.name}"? This action cannot be undone.`}
        colorType="red"
      />
    </Layout>
  );
};
